package dev.zonelock;

import com.github.retrooper.packetevents.PacketEvents;
import dev.zonelock.commands.CombatCommand;
import dev.zonelock.commands.ZoneCommand;
import dev.zonelock.listeners.CombatListener;
import dev.zonelock.listeners.ZoneListener;
import dev.zonelock.managers.BorderManager;
import dev.zonelock.managers.CombatManager;
import dev.zonelock.managers.ZoneManager;
import dev.zonelock.models.Zone;
import io.github.retrooper.packetevents.factory.spigot.SpigotPacketEventsBuilder;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class ZoneLock extends JavaPlugin {

    private ZoneManager   zoneManager;
    private CombatManager combatManager;
    private BorderManager borderManager;

    @Override
    public void onLoad() {
        // PacketEvents must be initialized in onLoad
        PacketEvents.setAPI(SpigotPacketEventsBuilder.build(this));
        PacketEvents.getAPI().load();
    }

    @Override
    public void onEnable() {
        PacketEvents.getAPI().init();
        saveDefaultConfig();

        zoneManager   = new ZoneManager(this);
        combatManager = new CombatManager(this);
        borderManager = new BorderManager(this);

        // Register listeners
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new ZoneListener(this),   this);

        // Register commands
        getCommand("zone").setExecutor(new ZoneCommand(this));
        CombatCommand cc = new CombatCommand(this);
        getCommand("combattag").setExecutor(cc);
        getCommand("combatuntag").setExecutor(cc);

        // HUD ticker — keeps action bar visible even when standing still
        getServer().getScheduler().runTaskTimer(this, () -> {
            for (Player p : getServer().getOnlinePlayers()) {
                Zone zone = zoneManager.getZoneAt(p.getLocation());
                if (zone == null) continue;
                if (zone.getType() == Zone.Type.PVP) {
                    p.sendActionBar(Component.text(
                        "⚔ PvP Zone — You can be attacked!", NamedTextColor.RED));
                } else {
                    p.sendActionBar(Component.text(
                        "🛡 Safe Zone — PvP Disabled", NamedTextColor.GREEN));
                }
            }
        }, 0L, 25L); // every 1.25 seconds

        getLogger().info("ZoneLock v" + getDescription().getVersion() + " enabled!");
    }

    @Override
    public void onDisable() {
        PacketEvents.getAPI().terminate();
        getLogger().info("ZoneLock disabled.");
    }

    public ZoneManager   getZoneManager()   { return zoneManager; }
    public CombatManager getCombatManager() { return combatManager; }
    public BorderManager getBorderManager() { return borderManager; }
}

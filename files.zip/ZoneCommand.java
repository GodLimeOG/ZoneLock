package dev.zonelock.commands;

import com.sk89q.worldedit.LocalSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.regions.Region;
import dev.zonelock.ZoneLock;
import dev.zonelock.models.Zone;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class ZoneCommand implements CommandExecutor {

    private final ZoneLock plugin;

    public ZoneCommand(ZoneLock plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return true;
        }
        if (!player.hasPermission("zonelock.admin")) {
            player.sendMessage("§cYou don't have permission.");
            return true;
        }
        if (args.length == 0) { sendHelp(player); return true; }

        switch (args[0].toLowerCase()) {

            case "create" -> {
                if (args.length < 3) {
                    player.sendMessage("§cUsage: /zone create <name> <pvp|safe>");
                    return true;
                }
                Zone.Type type;
                try { type = Zone.Type.valueOf(args[2].toUpperCase()); }
                catch (IllegalArgumentException e) {
                    player.sendMessage("§cType must be §epvp §cor §esafe§c.");
                    return true;
                }
                try {
                    LocalSession session = WorldEdit.getInstance()
                        .getSessionManager().get(BukkitAdapter.adapt(player));
                    Region region = session.getSelection(BukkitAdapter.adapt(player.getWorld()));
                    if (region == null) {
                        player.sendMessage("§cSelect an area with WorldEdit first (use //wand)!");
                        return true;
                    }
                    var min = region.getMinimumPoint();
                    var max = region.getMaximumPoint();
                    Zone zone = new Zone(args[1], player.getWorld().getName(),
                        min.getX(), min.getY(), min.getZ(),
                        max.getX(), max.getY(), max.getZ(), type);
                    plugin.getZoneManager().addZone(zone);
                    player.sendMessage("§aCreated §e" + type + " §azone: §6" + args[1]);
                } catch (Exception e) {
                    player.sendMessage("§cError: " + e.getMessage());
                }
            }

            case "delete" -> {
                if (args.length < 2) { player.sendMessage("§cUsage: /zone delete <name>"); return true; }
                if (plugin.getZoneManager().removeZone(args[1])) {
                    player.sendMessage("§aDeleted zone: §6" + args[1]);
                } else {
                    player.sendMessage("§cZone '§e" + args[1] + "§c' not found.");
                }
            }

            case "list" -> {
                var zones = plugin.getZoneManager().getZones();
                if (zones.isEmpty()) { player.sendMessage("§7No zones defined yet."); return true; }
                player.sendMessage("§6=== Zones (" + zones.size() + ") ===");
                for (Zone z : zones) {
                    String color = z.getType() == Zone.Type.PVP ? "§c" : "§a";
                    player.sendMessage("  §e" + z.getName() + " §7- " + color + z.getType() + " §7(" + z.getWorld() + ")");
                }
            }

            case "info" -> {
                if (args.length < 2) { player.sendMessage("§cUsage: /zone info <name>"); return true; }
                Zone z = plugin.getZoneManager().getZone(args[1]);
                if (z == null) { player.sendMessage("§cZone not found."); return true; }
                String color = z.getType() == Zone.Type.PVP ? "§c" : "§a";
                player.sendMessage("§6=== " + z.getName() + " ===");
                player.sendMessage("§7Type:  " + color + z.getType());
                player.sendMessage("§7World: §f" + z.getWorld());
                player.sendMessage("§7Min:   §f" + fmt(z.getMinX()) + ", " + fmt(z.getMinY()) + ", " + fmt(z.getMinZ()));
                player.sendMessage("§7Max:   §f" + fmt(z.getMaxX()) + ", " + fmt(z.getMaxY()) + ", " + fmt(z.getMaxZ()));
            }

            default -> sendHelp(player);
        }
        return true;
    }

    private void sendHelp(Player p) {
        p.sendMessage("§6=== ZoneLock ===");
        p.sendMessage("§e/zone create <name> <pvp|safe> §7- Create from WorldEdit selection");
        p.sendMessage("§e/zone delete <name>            §7- Delete a zone");
        p.sendMessage("§e/zone list                     §7- List all zones");
        p.sendMessage("§e/zone info <name>              §7- Zone details");
    }

    private String fmt(double v) { return String.valueOf((int) v); }
}

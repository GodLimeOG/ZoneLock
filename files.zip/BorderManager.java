package dev.zonelock.managers;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.util.Vector3i;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerBlockChange;
import dev.zonelock.ZoneLock;
import io.github.retrooper.packetevents.util.SpigotConversionUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.List;

public class BorderManager {

    private final ZoneLock plugin;

    public BorderManager(ZoneLock plugin) {
        this.plugin = plugin;
    }

    /**
     * Shows a temporary fake red glass barrier at the crossing point,
     * visible only to the given player. Auto-restores after 2 seconds.
     */
    public void showBarrier(Player player, Location crossing) {
        int x = crossing.getBlockX();
        int y = crossing.getBlockY();
        int z = crossing.getBlockZ();
        World world = crossing.getWorld();

        // Build a cross-shaped pillar 3 blocks tall
        List<Vector3i> positions = new ArrayList<>();
        for (int dy = 0; dy <= 2; dy++) {
            for (int d = -1; d <= 1; d++) {
                positions.add(new Vector3i(x + d, y + dy, z));
                positions.add(new Vector3i(x,     y + dy, z + d));
            }
        }

        int glassId = SpigotConversionUtil
            .fromBukkitBlockData(plugin.getServer().createBlockData(Material.RED_STAINED_GLASS_PANE))
            .getGlobalId();

        // Send fake glass blocks
        for (Vector3i pos : positions) {
            sendBlock(player, pos, glassId);
        }

        // Restore real blocks after 2 seconds (40 ticks)
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;
                for (Vector3i pos : positions) {
                    int realId = SpigotConversionUtil
                        .fromBukkitBlockData(world.getBlockAt(pos.x, pos.y, pos.z).getBlockData())
                        .getGlobalId();
                    sendBlock(player, pos, realId);
                }
            }
        }.runTaskLater(plugin, 40L);
    }

    private void sendBlock(Player player, Vector3i pos, int stateId) {
        WrapperPlayServerBlockChange packet = new WrapperPlayServerBlockChange(pos, stateId);
        PacketEvents.getAPI().getPlayerManager().sendPacket(player, packet);
    }
}

package dev.zonelock.models;

import org.bukkit.Location;

public class Zone {

    public enum Type { PVP, SAFE }

    private final String name;
    private final String world;
    private final double minX, minY, minZ;
    private final double maxX, maxY, maxZ;
    private final Type type;

    public Zone(String name, String world,
                double x1, double y1, double z1,
                double x2, double y2, double z2,
                Type type) {
        this.name = name;
        this.world = world;
        this.minX = Math.min(x1, x2);
        this.minY = Math.min(y1, y2);
        this.minZ = Math.min(z1, z2);
        this.maxX = Math.max(x1, x2);
        this.maxY = Math.max(y1, y2);
        this.maxZ = Math.max(z1, z2);
        this.type = type;
    }

    public boolean contains(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;
        if (!loc.getWorld().getName().equals(world)) return false;
        double x = loc.getX(), y = loc.getY(), z = loc.getZ();
        return x >= minX && x <= maxX
            && y >= minY && y <= maxY
            && z >= minZ && z <= maxZ;
    }

    public String getName()  { return name; }
    public String getWorld() { return world; }
    public Type   getType()  { return type; }
    public double getMinX()  { return minX; }
    public double getMinY()  { return minY; }
    public double getMinZ()  { return minZ; }
    public double getMaxX()  { return maxX; }
    public double getMaxY()  { return maxY; }
    public double getMaxZ()  { return maxZ; }
}

package dev.zonelock.listeners;

import dev.zonelock.ZoneLock;
import dev.zonelock.models.Zone;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class CombatListener implements Listener {

    private final ZoneLock plugin;

    public CombatListener(ZoneLock plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (!(event.getDamager() instanceof Player attacker)) return;

        Zone zone = plugin.getZoneManager().getZoneAt(victim.getLocation());

        // Cancel PvP outside PvP zones
        if (zone == null || zone.getType() != Zone.Type.PVP) {
            event.setCancelled(true);
            attacker.sendActionBar(
                net.kyori.adventure.text.Component.text(
                    "⚔ PvP is only allowed inside PvP zones!",
                    net.kyori.adventure.text.format.NamedTextColor.RED));
            return;
        }

        // Tag both players
        plugin.getCombatManager().tag(victim);
        plugin.getCombatManager().tag(attacker);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getCombatManager().handleLogout(event.getPlayer());
    }
}

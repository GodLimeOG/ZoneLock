package dev.zonelock.commands;

import dev.zonelock.ZoneLock;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class CombatCommand implements CommandExecutor {

    private final ZoneLock plugin;

    public CombatCommand(ZoneLock plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, String[] args) {

        if (!sender.hasPermission("zonelock.admin")) {
            sender.sendMessage("§cNo permission.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("§cUsage: /" + label + " <player>");
            return true;
        }

        Player target = plugin.getServer().getPlayer(args[0]);
        if (target == null) {
            sender.sendMessage("§cPlayer '§e" + args[0] + "§c' not found.");
            return true;
        }

        if (label.equalsIgnoreCase("combattag")) {
            plugin.getCombatManager().tag(target);
            sender.sendMessage("§aTagged §e" + target.getName() + " §ain combat.");
        } else {
            plugin.getCombatManager().untag(target);
            sender.sendMessage("§aRemoved combat tag from §e" + target.getName() + "§a.");
        }
        return true;
    }
}

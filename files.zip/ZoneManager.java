package dev.zonelock.managers;

import dev.zonelock.ZoneLock;
import dev.zonelock.models.Zone;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ZoneManager {

    private final ZoneLock plugin;
    private final List<Zone> zones = new ArrayList<>();
    private File zonesFile;
    private YamlConfiguration zonesConfig;

    public ZoneManager(ZoneLock plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        zonesFile = new File(plugin.getDataFolder(), "zones.yml");
        if (!zonesFile.exists()) {
            try { zonesFile.createNewFile(); }
            catch (IOException e) { e.printStackTrace(); }
        }
        zonesConfig = YamlConfiguration.loadConfiguration(zonesFile);
        zones.clear();

        var section = zonesConfig.getConfigurationSection("zones");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            String p = "zones." + key;
            Zone zone = new Zone(
                key,
                zonesConfig.getString(p + ".world"),
                zonesConfig.getDouble(p + ".minX"),
                zonesConfig.getDouble(p + ".minY"),
                zonesConfig.getDouble(p + ".minZ"),
                zonesConfig.getDouble(p + ".maxX"),
                zonesConfig.getDouble(p + ".maxY"),
                zonesConfig.getDouble(p + ".maxZ"),
                Zone.Type.valueOf(zonesConfig.getString(p + ".type", "SAFE"))
            );
            zones.add(zone);
        }
        plugin.getLogger().info("Loaded " + zones.size() + " zone(s).");
    }

    public void save() {
        for (Zone z : zones) {
            String p = "zones." + z.getName();
            zonesConfig.set(p + ".world", z.getWorld());
            zonesConfig.set(p + ".minX",  z.getMinX());
            zonesConfig.set(p + ".minY",  z.getMinY());
            zonesConfig.set(p + ".minZ",  z.getMinZ());
            zonesConfig.set(p + ".maxX",  z.getMaxX());
            zonesConfig.set(p + ".maxY",  z.getMaxY());
            zonesConfig.set(p + ".maxZ",  z.getMaxZ());
            zonesConfig.set(p + ".type",  z.getType().name());
        }
        try { zonesConfig.save(zonesFile); }
        catch (IOException e) { e.printStackTrace(); }
    }

    public void addZone(Zone zone) {
        zones.removeIf(z -> z.getName().equalsIgnoreCase(zone.getName()));
        zones.add(zone);
        save();
    }

    public boolean removeZone(String name) {
        boolean removed = zones.removeIf(z -> z.getName().equalsIgnoreCase(name));
        if (removed) {
            zonesConfig.set("zones." + name, null);
            try { zonesConfig.save(zonesFile); }
            catch (IOException e) { e.printStackTrace(); }
        }
        return removed;
    }

    /** PVP zones take priority over SAFE zones when overlapping. */
    public Zone getZoneAt(Location loc) {
        if (loc == null) return null;
        for (Zone z : zones)
            if (z.getType() == Zone.Type.PVP && z.contains(loc)) return z;
        for (Zone z : zones)
            if (z.getType() == Zone.Type.SAFE && z.contains(loc)) return z;
        return null;
    }

    public Zone getZone(String name) {
        return zones.stream()
            .filter(z -> z.getName().equalsIgnoreCase(name))
            .findFirst().orElse(null);
    }

    public List<Zone> getZones() { return zones; }
}

package dev.zonelock.listeners;

import dev.zonelock.ZoneLock;
import dev.zonelock.models.Zone;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

public class ZoneListener implements Listener {

    private final ZoneLock plugin;
    private final Map<UUID, String> lastZone = new HashMap<>();

    public ZoneListener(ZoneLock plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onMove(PlayerMoveEvent event) {
        if (!event.hasChangedBlock()) return;

        Player player = event.getPlayer();
        Zone to   = plugin.getZoneManager().getZoneAt(event.getTo());
        Zone from = plugin.getZoneManager().getZoneAt(event.getFrom());

        // --- Block combat-tagged players from entering Safe zones ---
        if (plugin.getCombatManager().isTagged(player)
                && to != null && to.getType() == Zone.Type.SAFE) {
            event.setCancelled(true);
            player.sendActionBar(Component.text(
                "🚫 Cannot enter safe zone! ("
                + plugin.getCombatManager().getTimer(player) + "s remaining)",
                NamedTextColor.RED));
            plugin.getBorderManager().showBarrier(player, event.getTo());
            return;
        }

        // --- Zone transition titles ---
        String nowName  = to   != null ? to.getName()   : null;
        String prevName = from != null ? from.getName() : null;
        String trackedPrev = lastZone.get(player.getUniqueId());

        if (!Objects.equals(nowName, trackedPrev)) {
            lastZone.put(player.getUniqueId(), nowName);
            if (to != null) {
                if (to.getType() == Zone.Type.PVP) {
                    player.showTitle(Title.title(
                        Component.text("⚔ PvP Zone",        NamedTextColor.RED),
                        Component.text("Combat is enabled here", NamedTextColor.GRAY)
                    ));
                } else {
                    player.showTitle(Title.title(
                        Component.text("🛡 Safe Zone",  NamedTextColor.GREEN),
                        Component.text("You are protected", NamedTextColor.GRAY)
                    ));
                }
            }
        }

        // --- Persistent action bar HUD ---
        if (to != null) {
            if (to.getType() == Zone.Type.PVP) {
                player.sendActionBar(Component.text(
                    "⚔ PvP Zone — You can be attacked!", NamedTextColor.RED));
            } else {
                player.sendActionBar(Component.text(
                    "🛡 Safe Zone — PvP Disabled", NamedTextColor.GREEN));
            }
        }
    }
}

package dev.zonelock.managers;

import dev.zonelock.ZoneLock;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CombatManager {

    private final ZoneLock plugin;
    private final Map<UUID, Integer> timers   = new HashMap<>();
    private final Map<UUID, Integer> tasks    = new HashMap<>();
    private final Map<UUID, BossBar> bossBars = new HashMap<>();

    public CombatManager(ZoneLock plugin) {
        this.plugin = plugin;
    }

    public void tag(Player player) {
        if (player.hasPermission("zonelock.bypass")) return;

        int duration = plugin.getConfig().getInt("combat-tag-duration", 15);
        UUID id = player.getUniqueId();

        // Cancel existing task if re-tagged
        if (tasks.containsKey(id)) {
            plugin.getServer().getScheduler().cancelTask(tasks.get(id));
        }

        timers.put(id, duration);

        // Create or reuse boss bar
        BossBar bar = bossBars.computeIfAbsent(id, uuid -> {
            BossBar b = BossBar.bossBar(
                Component.text("⚔ Combat Tag", NamedTextColor.RED),
                1.0f, BossBar.Color.RED, BossBar.Overlay.PROGRESS
            );
            player.showBossBar(b);
            return b;
        });

        player.setGlowing(true);

        int taskId = new BukkitRunnable() {
            int seconds = duration;
            @Override
            public void run() {
                seconds--;
                timers.put(id, seconds);
                bar.name(Component.text("⚔ Combat: " + seconds + "s", NamedTextColor.RED));
                bar.progress(Math.max(0f, (float) seconds / duration));
                if (seconds <= 0) {
                    untag(player);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 20L, 20L).getTaskId();

        tasks.put(id, taskId);
    }

    public void untag(Player player) {
        UUID id = player.getUniqueId();
        timers.remove(id);
        if (tasks.containsKey(id)) {
            plugin.getServer().getScheduler().cancelTask(tasks.remove(id));
        }
        BossBar bar = bossBars.remove(id);
        if (bar != null) player.hideBossBar(bar);
        player.setGlowing(false);
    }

    public boolean isTagged(Player player) {
        return timers.containsKey(player.getUniqueId());
    }

    public int getTimer(Player player) {
        return timers.getOrDefault(player.getUniqueId(), 0);
    }

    /** Called on PlayerQuitEvent — punish logout if configured. */
    public void handleLogout(Player player) {
        if (!isTagged(player)) return;
        if (plugin.getConfig().getBoolean("punish-combat-logout", true)) {
            player.setHealth(0);
        }
        untag(player);
    }
}
